"""Run route-(C) chunks from jobs.json EXACTLY as the lab stream does (producer | consumer), anywhere (Linux/Windows).
Usage: python run_jobs.py [--slice i/m] [--workers W] [--out results] [--only lid:k,...] [--upload "aws s3 cp {file} s3://B/results/{name}"] [--shutdown]
Checks the package against MANIFEST.json first (sha256 of every file) and refuses to run on any mismatch."""
import os, sys, json, time, hashlib, subprocess, argparse, shutil
ROOT = os.path.dirname(os.path.abspath(__file__))


def check_manifest():
    man = json.load(open(os.path.join(ROOT, "MANIFEST.json")))
    bad = [f for f, h in man["files"].items() if f not in ("MANIFEST.json",) and
           (not os.path.exists(os.path.join(ROOT, f)) or hashlib.sha256(open(os.path.join(ROOT, f), "rb").read()).hexdigest() != h)]
    if bad: sys.exit("MANIFEST MISMATCH, refusing to run: %s" % bad[:10])
    return man


def env_exact():
    e = {k: v for k, v in os.environ.items() if not (k.startswith("FD_") or k.startswith("STREAM_"))}   # every engine flag at its default
    e.update(OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", NUMBA_NUM_THREADS="1", FD_LEMMA_U="1", FD_SYM="1")
    return e


def start(job, out, env):
    lid, k, n = job["lid"], job["k"], job["n"]; tag = "%s_%d_%d" % (lid, k, n)
    res = os.path.join(out, tag + ".jsonl"); stats = os.path.join(out, tag + "_producer_stats.json")
    U = os.path.join(ROOT, "external_runs", "structures_3eceb4d", "U", "%s.json" % lid)
    prod = subprocess.Popen([sys.executable, os.path.join(ROOT, "c1", "code", "y_pairs_gamma.py"), U, os.path.join(ROOT, job["gamma"]), stats,
                             "--from-plan", os.path.join(ROOT, job["plan"]), "--chunk", "%d/%d" % (k, n), "--stream", "-", "--max-seconds", "86400"],
                            env=env, cwd=os.path.join(ROOT, "c1", "code"), stdout=subprocess.PIPE, stderr=open(os.path.join(out, tag + "_producer.err"), "w"))
    cons = subprocess.Popen([sys.executable, os.path.join(ROOT, "scripts", "hstage_stream_next.py"), lid, "-", res], env=env, cwd=ROOT, stdin=prod.stdout,
                            stdout=open(os.path.join(out, tag + "_consumer.out"), "w"), stderr=subprocess.STDOUT)
    prod.stdout.close()
    return {"job": job, "tag": tag, "prod": prod, "cons": cons, "res": res, "t0": time.time()}


def done_already(out, job):
    f = os.path.join(out, "%s_%d_%d.jsonl" % (job["lid"], job["k"], job["n"]))
    if not os.path.exists(f): return False
    return any(json.loads(l).get("chunk_ok") for l in open(f) if l.strip())


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--slice", default="0/1"); ap.add_argument("--workers", type=int, default=os.cpu_count())
    ap.add_argument("--out", default=os.path.join(ROOT, "results")); ap.add_argument("--only", default=""); ap.add_argument("--upload", default="")
    ap.add_argument("--shutdown", action="store_true"); a = ap.parse_args()
    man = check_manifest(); a.out = os.path.abspath(a.out); os.makedirs(a.out, exist_ok=True)
    jobs = json.load(open(os.path.join(ROOT, "jobs.json")))
    if a.only: keep = {tuple(x.split(":")) for x in a.only.split(",")}; jobs = [j for j in jobs if (j["lid"], str(j["k"])) in keep]
    else: jobs = [j for j in jobs if not j.get("calib")]                  # calibration jobs only on request (--only 118:2)
    i, m = map(int, a.slice.split("/")); jobs = [j for t, j in enumerate(jobs) if t % m == i]
    jobs = [j for j in jobs if not done_already(a.out, j)]
    env = env_exact(); running = []; log = open(os.path.join(a.out, "run_jobs.log"), "a"); total = len(jobs); ndone = 0
    log.write("%s start: %d jobs, %d workers, engine %s, c1 %s\n" % (time.strftime("%F %T"), len(jobs), a.workers, man["engine_code_sha"], man["c1_commit"])); log.flush()
    while jobs or running:
        while jobs and len(running) < a.workers: running.append(start(jobs.pop(0), a.out, env))
        for r in list(running):
            if r["cons"].poll() is None: continue
            r["prod"].wait(); running.remove(r); ndone += 1
            log.write("%s %s done in %.0fs (producer %s consumer %s) -- %d/%d jobs of this slice done\n" % (time.strftime("%F %T"), r["tag"], time.time() - r["t0"], r["prod"].returncode, r["cons"].returncode, ndone, total)); log.flush()
            if a.upload:
                for f in os.listdir(a.out):
                    if f.startswith(r["tag"]): subprocess.run(a.upload.format(file=os.path.join(a.out, f), name=f), shell=True)
        time.sleep(5)
    log.write("%s all jobs finished\n" % time.strftime("%F %T")); log.close()
    arc = shutil.make_archive(os.path.join(ROOT, "RESULTATS_slice_%s" % a.slice.replace("/", "of")), "gztar", a.out)   # the one file to bring back
    print("FINISHED. Bring back this file:", arc, flush=True)
    if a.upload: subprocess.run(a.upload.format(file=os.path.join(a.out, "run_jobs.log"), name="run_jobs_%s.log" % a.slice.replace("/", "of")), shell=True)
    if a.shutdown and os.name != "nt": subprocess.run(["sudo", "shutdown", "-h", "now"])


if __name__ == "__main__":
    main()
