"""Package v4 job kind "golay_pairs" (C2, 2026-10-02): a contiguous block of the (y1, y2) pair classes of a Golay-family envelope,
written in the Golay A1^24 frame, as a queue job "<lid>:<k>:<n>".
Pair lists: data/golay/<lid>/pairs_*.json, sorted by name; block k of n = pairs [N k / n, N (k+1) / n) of their concatenation.
  * id 001: structures' pipeline (golay_family / golay_y / golay_y2 / golay_y3 / golay_swapfilter, reproduced in the lab), format
    {"basis", "scale", "y1_class", "pairs": [[y1, y2], ...]};
  * ids 002, 004, 010: golay_work/golay_gen.py (the same pipeline for any frame, validated on 001: identical admissible y set,
    identical 14 y1 classes, identical pair-class counts for all 14 classes), compact format {"basis", "scale", "y1_class", "y1", "y2s"}.
Every pair of the block, in this order (all sound):
  1. characteristic trap (Astra 28/09, checked by C2): EXCLUDED (char-vector trap);
  2. twin envelope U+ (Astra sec. 5): if EVERY envelope of its root type is excluded in the shipped tracker: EXCLUDED (twin transfer);
  3. otherwise the exact stage-1 search of frame_dfs_next (FD_SYM3), node limit 2e8; a pair still INCOMPLETE is searched again
     with node limit 4e9 (v4; the first attempt is recorded).
The pair lists are already reduced by G1 orbits and the swap filter, so C2's swap rule is NOT applied again.
v4 also reads the pair files one at a time and keeps only the block (memory bounded by the largest file).
chunk_ok = every pair of the block processed; chunk_done = every pair EXCLUDED. Non-excluded pairs (INCOMPLETE, a leaf, ...) are listed.
Usage: python scripts/golay_pairs_job.py <lid> <k> <n> <res.jsonl>"""
import sys, os, json, time, hashlib, collections, glob
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, HERE)
for v_ in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"): os.environ.setdefault(v_, "1")
os.environ.setdefault("FD_LEMMA_U", "1"); os.environ.setdefault("FD_SYM", "1"); os.environ.setdefault("FD_SYM3", "1")
import numpy as np
from fractions import Fraction as F
CODE_SHA = {f: hashlib.sha256(open(os.path.join(HERE, f), "rb").read()).hexdigest()[:16]
            for f in ("frame_dfs_next.py", "twin_transfer.py", "golay_pairs_job.py")}
NODE_LIMIT = 2 * 10 ** 8
RETRY_LIMIT = 4 * 10 ** 9


def pairs_of(d):
    if "pairs" in d:
        return d["pairs"]
    return [[d["y1"], y2] for y2 in d["y2s"]]


def load_block(files, k, n):
    """-> (meta of the first file, sha256 of the concatenated files, N, a, b, [(y1_class, [y1, y2]) for the block])"""
    h = hashlib.sha256(); counts = []; meta = None
    for f in files:
        raw = open(f, "rb").read(); h.update(raw); d = json.loads(raw)
        m = (d["basis"], d["scale"], d.get("frame"))
        if meta is None: meta = m
        assert m[:2] == meta[:2], "pair files in different frames"
        counts.append(len(d["pairs"]) if "pairs" in d else len(d["y2s"])); del d, raw
    N = sum(counts); a, b = N * k // n, N * (k + 1) // n; out = []; off = 0
    for f, c in zip(files, counts):
        if off < b and off + c > a:
            d = json.load(open(f)); P = pairs_of(d)
            out += [(d.get("y1_class"), P[i]) for i in range(max(a, off) - off, min(b, off + c) - off)]
            del d, P
        off += c
    return meta, h.hexdigest(), N, a, b, out


def run_pair(L, y1, y2, CL, base=NODE_LIMIT, retry=RETRY_LIMIT):
    """-> (verdict, nodes, retry_info or None): the per-pair logic of the job (also used by calib_v4.py with small limits)"""
    from frame_dfs_next import search, char_trap
    import twin_transfer as TT
    if char_trap(L, y1, y2) is not None:
        return "EXCLUDED (char-vector trap)", None, None
    Rt = TT.twin_roots(L, y1, y2); ty = TT.rtype(Rt, L["G"]) if len(Rt) else ()
    if CL.get(ty, {"?"}) == {"excluded"}:
        return "EXCLUDED (twin transfer)", None, None
    try:
        r = search(L, y1, y2, node_limit=base)
    except AssertionError as e:
        return "INVALID (%s)" % str(e)[:80], None, None
    v = r["verdict"]; info = None
    if v.startswith("INCOMPLETE") and retry:
        t = time.time()
        try:
            r2 = search(L, y1, y2, node_limit=retry)
        except AssertionError as e:
            r2 = {"verdict": "INVALID (%s)" % str(e)[:80]}
        info = {"first_verdict": v, "first_nodes": r.get("nodes"), "retry_limit": retry, "retry_secs": round(time.time() - t, 1),
                "retry_nodes": r2.get("nodes")}
        v = r2["verdict"]; r = r2
    return v, r.get("nodes"), info


def main():
    lid = "%03d" % int(sys.argv[1]); k = int(sys.argv[2]); n = int(sys.argv[3]); res = sys.argv[4]; t0 = time.time()
    from frame_dfs_next import lattice_data
    import twin_transfer as TT
    files = sorted(glob.glob(os.path.join(ROOT, "data", "golay", lid, "pairs_*.json")))
    assert files, "no pair files"
    (basis, scale, frame), fsha, N, a, b, pairs = load_block(files, k, n)
    L = lattice_data([[F(x) for x in row] for row in basis], F(1, int(scale)))
    Bf = np.array([[float(x) for x in row] for row in L["B"]]); Binv = np.linalg.inv(Bf)
    Bq = [[F(x) for x in row] for row in L["B"]]

    def conv(v):
        cf = np.rint(np.array([float(F(x)) for x in v]) @ Binv).astype(np.int64)
        assert all(sum(int(c) * Bq[i][j] for i, c in enumerate(cf)) == F(v[j]) for j in range(len(v))), "y not in U"
        return cf
    CL = TT.classes(); cnt = collections.Counter(); keep = []; retried = []
    for t, (c1, (s1, s2)) in enumerate(pairs):
        idx = a + t
        y1, y2 = conv(s1), conv(s2)
        v, nodes, info = run_pair(L, y1, y2, CL)
        cnt[v] += 1
        if info is not None:
            retried.append(dict(info, index=idx, y1_class=c1, verdict=v))
        if not v.startswith("EXCLUDED"):
            keep.append({"index": idx, "y1_class": c1, "y1": [str(x) for x in s1], "y2": [str(x) for x in s2], "verdict": v, "nodes": nodes})
    done = sum(c for v, c in cnt.items() if v.startswith("EXCLUDED"))
    rec = {"id": int(lid), "kind": "golay_pairs", "chunk": [k, n], "range": [a, b], "n_pairs": b - a, "pairs_total": N, "pair_files_sha256": fsha,
           "frame": frame, "verdicts": dict(cnt), "not_excluded": keep, "retried": retried, "chunk_ok": True, "chunk_done": done == b - a,
           "code_sha": CODE_SHA, "node_limit": NODE_LIMIT, "retry_limit": RETRY_LIMIT, "wall_secs": round(time.time() - t0, 1),
           "machine": os.environ.get("Q_NAME", "local"), "t": time.strftime("%Y-%m-%d %H:%M:%S")}
    open(res, "a").write(json.dumps(rec) + "\n")
    print(json.dumps({x: rec[x] for x in ("chunk", "n_pairs", "verdicts", "chunk_done", "wall_secs")}), flush=True)


if __name__ == "__main__":
    main()
