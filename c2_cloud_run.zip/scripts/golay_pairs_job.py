"""Package v3 job kind "golay_pairs" (C2, 2026-10-02): a contiguous block of the (y1, y2) pair classes of a Golay-family envelope,
written in the Golay A1^24 frame by structures' pipeline (golay_family / golay_y / golay_y3 / golay_swapfilter, reproduced in the lab
on 02/10: same 14 y1 classes and the same pair counts for classes 0 and 1), as a queue job "<lid>:<k>:<n>".
Every pair of the block, in this order (all sound):
  1. characteristic trap (Astra 28/09, checked by C2): EXCLUDED (char-vector trap);
  2. twin envelope U+ (Astra sec. 5): its root system type is computed from the twin roots; if EVERY envelope of that type is excluded
     in the shipped tracker, the pair is EXCLUDED (twin transfer). No deferral and no twin-canonical skip here (conservative);
  3. otherwise the exact stage-1 search of frame_dfs_next (FD_SYM3: symmetry at every depth, two-phase), node limit 2e8.
The pair lists are already reduced by structures (G1 orbits, swap filter), so C2's swap rule is NOT applied again.
chunk_ok = every pair of the block processed; chunk_done = every pair EXCLUDED. Non-excluded pairs (INCOMPLETE, a leaf, ...) are listed.
Usage: python scripts/golay_pairs_job.py <lid> <k> <n> <res.jsonl>     (pair files: data/golay/<lid>/pairs_*.json, sorted by name)"""
import sys, os, json, time, hashlib, collections, glob
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, HERE)
for v_ in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"): os.environ.setdefault(v_, "1")
os.environ.setdefault("FD_LEMMA_U", "1"); os.environ.setdefault("FD_SYM", "1"); os.environ.setdefault("FD_SYM3", "1")
import numpy as np
from fractions import Fraction as F
CODE_SHA = {f: hashlib.sha256(open(os.path.join(HERE, f), "rb").read()).hexdigest()[:16]
            for f in ("frame_dfs_next.py", "twin_transfer.py", "golay_pairs_job.py")}


def main():
    lid = "%03d" % int(sys.argv[1]); k = int(sys.argv[2]); n = int(sys.argv[3]); res = sys.argv[4]; t0 = time.time()
    from frame_dfs_next import lattice_data, search, char_trap
    import twin_transfer as TT
    files = sorted(glob.glob(os.path.join(ROOT, "data", "golay", lid, "pairs_*.json")))
    assert files, "no pair files"
    data = [json.load(open(f)) for f in files]
    basis = data[0]["basis"]; scale = data[0]["scale"]
    assert all(d["basis"] == basis and d["scale"] == scale for d in data), "pair files in different frames"
    fsha = hashlib.sha256(b"".join(open(f, "rb").read() for f in files)).hexdigest()
    pairs = [(d.get("y1_class"), p) for d in data for p in d["pairs"]]
    a, b = len(pairs) * k // n, len(pairs) * (k + 1) // n
    L = lattice_data([[F(x) for x in row] for row in basis], F(1, int(scale)))
    Bf = np.array([[float(x) for x in row] for row in L["B"]]); Binv = np.linalg.inv(Bf)
    Bq = [[F(x) for x in row] for row in L["B"]]

    def conv(v):
        cf = np.rint(np.array([float(F(x)) for x in v]) @ Binv).astype(np.int64)
        assert all(sum(int(c) * Bq[i][j] for i, c in enumerate(cf)) == F(v[j]) for j in range(len(v))), "y not in U"
        return cf
    CL = TT.classes(); cnt = collections.Counter(); keep = []
    for idx in range(a, b):
        c1, (s1, s2) = pairs[idx]
        y1, y2 = conv(s1), conv(s2)
        if char_trap(L, y1, y2) is not None:
            cnt["EXCLUDED (char-vector trap)"] += 1; continue
        Rt = TT.twin_roots(L, y1, y2); ty = TT.rtype(Rt, L["G"]) if len(Rt) else ()
        if CL.get(ty, {"?"}) == {"excluded"}:
            cnt["EXCLUDED (twin transfer)"] += 1; continue
        try:
            r = search(L, y1, y2, node_limit=2 * 10 ** 8)
        except AssertionError as e:
            r = {"verdict": "INVALID (%s)" % str(e)[:80]}
        v = r["verdict"]; cnt[v] += 1
        if not v.startswith("EXCLUDED"):
            keep.append({"index": idx, "y1_class": c1, "y1": s1, "y2": s2, "verdict": v, "nodes": r.get("nodes")})
    done = sum(c for v, c in cnt.items() if v.startswith("EXCLUDED"))
    rec = {"id": int(lid), "kind": "golay_pairs", "chunk": [k, n], "range": [a, b], "n_pairs": b - a, "pairs_total": len(pairs), "pair_files_sha256": fsha,
           "frame": data[0].get("frame"), "verdicts": dict(cnt), "not_excluded": keep, "chunk_ok": True, "chunk_done": done == b - a,
           "code_sha": CODE_SHA, "node_limit": 2 * 10 ** 8, "wall_secs": round(time.time() - t0, 1), "machine": os.environ.get("Q_NAME", "local"),
           "t": time.strftime("%Y-%m-%d %H:%M:%S")}
    open(res, "a").write(json.dumps(rec) + "\n")
    print(json.dumps({x: rec[x] for x in ("chunk", "n_pairs", "verdicts", "chunk_done", "wall_secs")}), flush=True)


if __name__ == "__main__":
    main()
