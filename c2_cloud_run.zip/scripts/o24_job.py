"""Package v3 job kind "o24" (C2, 2026-10-02): one O24 (y1, y2) class, exact search, as a queue job "000:<class>:141".
Runs o24_run_fast.run(class): kernel 3 (stage 1 + Lemma Z + local star sums in numba), then the numba joint star sums
(o24_joint_nb, validated by planted-solution tests against the Python joint) and the full (F) check on every joint solution.
Writes one JSON line to <res>: chunk_ok = the search completed (no node limit); chunk_done = complete and the verdict is EMPTY.
Any other verdict (joint survivors, FRAME FOUND) is still a finished job, and the lab importer must stop everything on it.
Usage: python scripts/o24_job.py <class> <res.jsonl>"""
import sys, os, json, time, hashlib
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
for v_ in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"): os.environ.setdefault(v_, "1")
CODE_SHA = {f: hashlib.sha256(open(os.path.join(HERE, f), "rb").read()).hexdigest()[:16]
            for f in ("o24_dfs.py", "o24_joint_nb.py", "o24_run_fast.py", "o24_job.py")}


def main():
    k = int(sys.argv[1]); res = sys.argv[2]; t0 = time.time()
    import o24_run_fast as R
    r = R.run(k)
    ok = bool(r["complete"])
    rec = {"id": 0, "kind": "o24", "chunk": [k, 141], "class": k, "verdict": r["verdict"], "complete": ok, "counts": r["counts"],
           "nodes_per_depth": r["nodes_per_depth"], "eligible_words": r["eligible_words"], "signed_octads": r["signed_octads"],
           "secs_dfs": r["secs_dfs"], "secs_stage2": r["secs_stage2"], "wall_secs": round(time.time() - t0, 1), "code_sha": CODE_SHA,
           "survivors": r["survivors"][:50], "frames": r["frames"], "chunk_ok": ok,
           "chunk_done": ok and r["verdict"].startswith("EMPTY"), "machine": os.environ.get("Q_NAME", "local"),
           "t": time.strftime("%Y-%m-%d %H:%M:%S")}
    open(res, "a").write(json.dumps(rec) + "\n")
    print(json.dumps({x: rec[x] for x in ("class", "verdict", "chunk_ok", "chunk_done", "wall_secs")}), flush=True)


if __name__ == "__main__":
    main()
