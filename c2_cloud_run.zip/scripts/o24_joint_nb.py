"""O24 stage 2, joint star sums in numba (C2, 2026-10-01). Same search as o24_dfs.stage2.joint (Python): 42 slots (Same and Opp for
each of the 21 pairs of chosen octads), slots ordered by size (stable, as Python), one word per slot, the 42 words distinct lines,
each word oriented towards the octad of its star (sign of V[c, t]); after each choice the two touched stars must stay feasible
(|target - partial| <= remaining and same parity, coordinate-wise). Returns all solutions up to cap (1000 in Python).
Validation: `python scripts/o24_joint_nb.py --selftest <class> [n_leaves]` runs a PLANTED-solution differential test against the
Python joint() on real leaves of the class: targets are replaced by the sums of a random valid assignment, so both searches must
find it, and their solution lists must be identical."""
import os, sys, time, random
import numpy as np
import numba as nb
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


@nb.njit(cache=True)
def joint_kernel(sx, sy, sw, sl, sgn, Wv, tgt, cap, out):
    """sx, sy: star indices (0..6) of each slot; sw[s, :sl[s]]: word indices; sgn[x, t] = +-1 orientation of word t in star x;
    Wv: words (nW x 24); tgt: 7 x 24 targets. Writes up to cap solutions into out (cap x nslots); returns the number found."""
    ns = sx.shape[0]; nW = Wv.shape[0]
    part = np.zeros((7, 24), np.int64); rem = np.full(7, 12, np.int64); used = np.zeros(nW, np.bool_)
    pos = -np.ones(ns, np.int64); choice = -np.ones(ns, np.int64); nsol = 0; i = 0
    while i >= 0:
        if i == ns:                                                      # a complete joint choice
            if nsol < cap:
                for s in range(ns): out[nsol, s] = choice[s]
            nsol += 1
            if nsol >= cap: return nsol
            i -= 1
            # undo slot i
            t = choice[i]; x = sx[i]; y = sy[i]
            for q in range(24): part[x, q] -= sgn[x, t] * Wv[t, q]; part[y, q] -= sgn[y, t] * Wv[t, q]
            rem[x] += 1; rem[y] += 1; used[t] = False; choice[i] = -1
            continue
        # advance slot i to its next admissible word
        if choice[i] >= 0:                                               # undo the previous word of slot i
            t = choice[i]; x = sx[i]; y = sy[i]
            for q in range(24): part[x, q] -= sgn[x, t] * Wv[t, q]; part[y, q] -= sgn[y, t] * Wv[t, q]
            rem[x] += 1; rem[y] += 1; used[t] = False; choice[i] = -1
        advanced = False
        while pos[i] + 1 < sl[i]:
            pos[i] += 1; t = sw[i, pos[i]]
            if used[t]: continue
            x = sx[i]; y = sy[i]
            for q in range(24): part[x, q] += sgn[x, t] * Wv[t, q]; part[y, q] += sgn[y, t] * Wv[t, q]
            rem[x] -= 1; rem[y] -= 1
            ok = True
            for z in (x, y):
                r = rem[z]
                for q in range(24):
                    d = tgt[z, q] - part[z, q]
                    if d > r or d < -r or (d - r) % 2 != 0:
                        ok = False; break
                if not ok: break
            if ok:
                used[t] = True; choice[i] = t; advanced = True; break
            for q in range(24): part[x, q] -= sgn[x, t] * Wv[t, q]; part[y, q] -= sgn[y, t] * Wv[t, q]
            rem[x] += 1; rem[y] += 1
        if advanced:
            i += 1
            if i < ns: pos[i] = -1
        else:
            pos[i] = -1; i -= 1
    return nsol


def ones(x):
    i = 0
    while x:
        if x & 1: yield i
        x >>= 1; i += 1


def build_slots(ctx, P):
    """exactly the slots of o24_dfs.stage2.joint (same Same/Opp sets, same stable order by size)"""
    import itertools
    Z, Pp, Pn = ctx["Z"], ctx["Pp"], ctx["Pn"]; ALLW = (1 << ctx["nW"]) - 1
    S = {}
    for x, y in itertools.combinations(range(len(P)), 2):
        c, d = P[x], P[y]; zo = ALLW
        for e in P:
            if e != c and e != d: zo &= Z[e]
        S[(x, y)] = (((Pp[c] & Pp[d]) | (Pn[c] & Pn[d])) & zo, ((Pp[c] & Pn[d]) | (Pn[c] & Pp[d])) & zo)
    slots = []
    for (x, y), (ss, os_) in sorted(S.items()): slots += [(x, y, 0, list(ones(ss))), (x, y, 1, list(ones(os_)))]
    slots.sort(key=lambda s: len(s[3]))
    return slots, S


def arrays(ctx, P, slots, tgt=None):
    Wv = np.array(ctx["words"], dtype=np.int64); Mv = np.array([ctx["Ms"][c][1] for c in P], dtype=np.int64)
    V = Mv @ Wv.T; sgn = np.where(V > 0, 1, -1).astype(np.int64)
    ns = len(slots); ml = max(1, max(len(s[3]) for s in slots))
    sx = np.array([s[0] for s in slots], np.int64); sy = np.array([s[1] for s in slots], np.int64)
    sw = np.zeros((ns, ml), np.int64); sl = np.array([len(s[3]) for s in slots], np.int64)
    for k, s in enumerate(slots): sw[k, :len(s[3])] = s[3]
    if tgt is None: tgt = 6 * Mv
    return sx, sy, sw, sl, sgn, Wv, np.ascontiguousarray(tgt, dtype=np.int64)


def joint_fast(ctx, P, cap=1000, tgt=None):
    slots, S = build_slots(ctx, P)
    a = arrays(ctx, P, slots, tgt)
    out = np.zeros((cap, len(slots)), np.int64)
    n = joint_kernel(*a, cap, out)
    return slots, [list(map(int, out[k])) for k in range(min(n, cap))]


if __name__ == "__main__" and len(sys.argv) > 2 and sys.argv[1] == "--selftest":
    import json
    import o24_dfs as OD
    k = int(sys.argv[2]); nl = int(sys.argv[3]) if len(sys.argv) > 3 else 6
    ctx = OD.build(k)
    res = json.load(open(os.path.join(OD.LAB, "data", "finishC", "o24_dfs", "class_%03d.json" % k)))
    idx = {tuple(m): i for i, (_, m) in enumerate(ctx["Ms"])}
    leaves = [[idx[tuple(m)] for m in s["M"]] for s in res.get("survivors", [])][:nl]
    if not leaves: sys.exit("no saved survivors for this class")
    rng = random.Random(7); t_py = t_nb = 0.0; ok = 0
    for P in leaves:
        slots, S = build_slots(ctx, P)
        # plant: a random assignment of distinct words, one per slot; its oriented star sums become the targets
        used = set(); pick = []
        for (x, y, kd, ts) in slots:
            free = [t for t in ts if t not in used]
            if not free: pick = None; break
            t = rng.choice(free); used.add(t); pick.append(t)
        if pick is None: print("leaf skipped (no distinct planting)"); continue
        Wv = np.array(ctx["words"], dtype=np.int64); Mv = np.array([ctx["Ms"][c][1] for c in P], dtype=np.int64); V = Mv @ Wv.T
        tgt = np.zeros((7, 24), np.int64)
        for (x, y, kd, ts), t in zip(slots, pick):
            tgt[x] += (1 if V[x, t] > 0 else -1) * Wv[t]; tgt[y] += (1 if V[y, t] > 0 else -1) * Wv[t]
        t0 = time.time(); _, sols_nb = joint_fast(ctx, P, 1000, tgt); t_nb += time.time() - t0
        # the Python reference with the same planted targets: o24_dfs.stage2.joint is a closure, so re-implement its loop here
        rem = [12] * 7; part = [[0] * 24 for _ in range(7)]; tg = tgt.tolist(); sols = []; choice = [None] * len(slots)
        def feas(x):
            r = rem[x]
            for q in range(24):
                d = tg[x][q] - part[x][q]
                if d > r or d < -r or (d - r) % 2: return False
            return True
        def go(i):
            if len(sols) >= 1000: return
            if i == len(slots): sols.append(list(choice)); return
            x, y, kd, ts = slots[i]
            for t in ts:
                if t in choice[:i]: continue
                ox = [(1 if V[x, t] > 0 else -1) * v for v in Wv[t]]; oy = [(1 if V[y, t] > 0 else -1) * v for v in Wv[t]]
                for q in range(24): part[x][q] += ox[q]; part[y][q] += oy[q]
                rem[x] -= 1; rem[y] -= 1; choice[i] = t
                if feas(x) and feas(y): go(i + 1)
                for q in range(24): part[x][q] -= ox[q]; part[y][q] -= oy[q]
                rem[x] += 1; rem[y] += 1; choice[i] = None
        t0 = time.time(); go(0); t_py += time.time() - t0
        same = sols == sols_nb and pick in sols
        ok += same
        print("leaf %s: planted found py %s nb %s | solutions py %d nb %d | identical %s" % (P, pick in sols, pick in sols_nb, len(sols), len(sols_nb), same), flush=True)
    print("class %d: %d/%d leaves identical (planted solution found by both); python %.1f s, numba %.2f s" % (k, ok, len(leaves), t_py, t_nb))
