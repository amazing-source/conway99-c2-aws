"""Package v6 job kind "resolve" (C2, 2026-10-02): INCOMPLETE stream pairs (stopped at the stream node limit) searched again with NO node
limit, as queue jobs "r<lid>:<i>:<m>" = pairs [P i / m, P (i+1) / m) of data/resolve/<lid>.json (list fixed when the package is built,
in the order scripts/resolve_incomplete_next.py visits them: chunks.jsonl order, then not_excluded order).
Same engine and setup as resolve_incomplete_next.py (frame_dfs_next; FD_LEMMA_U=1, FD_SYM=1, FD_SYM3=1; envelope basis of
external_runs/structures_3eceb4d/U/<lid>.json, scale 1; each y converted exactly). One JSON line per job with the verdict of each pair.
chunk_ok = every pair searched to the end; chunk_done = every pair EXCLUDED. The lab importer scripts/cloud/import_resolve.py appends the
results to data/finishC/stream/<lid>/incomplete_resolved.jsonl, which stream_finish.py reads.
Usage: python scripts/resolve_job.py <lid> <i> <m> <res.jsonl>"""
import sys, os, json, time, hashlib
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE); sys.path.insert(0, HERE)
for v_ in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"): os.environ.setdefault(v_, "1")
os.environ.setdefault("FD_LEMMA_U", "1"); os.environ.setdefault("FD_SYM", "1"); os.environ.setdefault("FD_SYM3", "1")
import numpy as np
from fractions import Fraction as F
CODE_SHA = {f: hashlib.sha256(open(os.path.join(HERE, f), "rb").read()).hexdigest()[:16] for f in ("frame_dfs_next.py", "resolve_job.py")}


def main():
    lid = "%03d" % int(sys.argv[1]); i = int(sys.argv[2]); m = int(sys.argv[3]); res = sys.argv[4]; t0 = time.time()
    from frame_dfs_next import lattice_data, search
    lst = json.load(open(os.path.join(ROOT, "data", "resolve", "%s.json" % lid)))
    assert lst["lid"] == lid
    P = lst["pairs"]; a, b = len(P) * i // m, len(P) * (i + 1) // m
    gens = json.load(open(os.path.join(ROOT, "external_runs", "structures_3eceb4d", "U", "%s.json" % lid)))["gens"]
    L = lattice_data(gens, F(1)); Bq = np.array([[F(x) for x in row] for row in L["B"]], dtype=object)
    Binv = np.linalg.inv(np.array([[float(x) for x in row] for row in L["B"]]))

    def conv(v):
        ex = np.array([F(t) for t in v], dtype=object)
        cf = np.rint(np.array([float(t) for t in ex]) @ Binv).astype(np.int64)
        assert np.array_equal(cf @ Bq, ex), "y not in U"
        return cf
    out = []
    for p in P[a:b]:
        t = time.time(); r = search(L, conv(p["y1"]), conv(p["y2"]), node_limit=0)
        out.append({"chunk": p["chunk"], "y1": p["y1"], "y2": p["y2"], "verdict": r["verdict"], "nodes": r.get("nodes"),
                    "secs": round(time.time() - t, 1), "node_limit": "none"})
    rec = {"id": int(lid), "kind": "resolve", "chunk": [i, m], "range": [a, b], "n_pairs": b - a, "list_sha256": lst["sha256"],
           "results": out, "verdicts": {v: sum(1 for x in out if x["verdict"] == v) for v in {x["verdict"] for x in out}},
           "chunk_ok": all(not x["verdict"].startswith("INCOMPLETE") for x in out),
           "chunk_done": all(x["verdict"].startswith("EXCLUDED") for x in out), "code_sha": CODE_SHA,
           "wall_secs": round(time.time() - t0, 1), "machine": os.environ.get("Q_NAME", "local"), "t": time.strftime("%Y-%m-%d %H:%M:%S")}
    open(res, "a").write(json.dumps(rec) + "\n")
    print(json.dumps({x: rec[x] for x in ("chunk", "n_pairs", "verdicts", "chunk_done", "wall_secs")}), flush=True)


if __name__ == "__main__":
    main()
