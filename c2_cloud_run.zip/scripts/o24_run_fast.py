"""O24 class runner with the numba joint stage (C2, 2026-10-01). Same pipeline as o24_dfs.run3 (kernel 3: stage 1 + Lemma Z +
local star sums in numba), then on the leaves that pass all local star sums:
  - Lemma Z and every local star sum re-checked in Python (o24_dfs.stage2's own code path, run with the joint step skipped),
  - the JOINT star sums with o24_joint_nb.joint_fast (validated against the Python joint by planted-solution tests),
  - the rest of (F) on every joint solution (same full_check as o24_dfs).
Writes data/finishC/o24_dfs/class_KKK.json (engine tag "nb3 + numba joint"). Usage: python scripts/o24_run_fast.py <class> [...]"""
import os, sys, json, time
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import o24_dfs as OD
import o24_joint_nb as J


def full_check(ctx, P, slots, sol):
    """identical to o24_dfs.stage2.full_check"""
    words, Ms, a1, a2 = ctx["words"], ctx["Ms"], ctx["a1"], ctx["a2"]
    def oriented(t, c):
        w = words[t]; m = Ms[c][1]; v = sum(w[i] * m[i] for i in range(24))
        return [x if v > 0 else -x for x in w]
    U, Cm = [], np.zeros((7, 42), dtype=np.int64)
    for o, ((x, y, kd, ts), t) in enumerate(zip(slots, sol)):
        u = oriented(t, P[x]); U.append(u)
        vy = sum(u[i] * Ms[P[y]][1][i] for i in range(24)) // 4
        Cm[x, o] = -1; Cm[y, o] = -vy
    Um = np.array(U, dtype=np.int64); G = Um @ Um.T; off = G - np.diag(np.diag(G))
    if not np.all(np.isin(off, (0, 8, -8))): return 0
    T = -off // 8
    if not np.array_equal(T @ T + T, 12 * np.eye(42, dtype=np.int64) - Cm.T @ Cm): return 1
    H = np.array([Ms[c][1] for c in P], dtype=np.int64) * 2; Ya = np.array([a1, a2], dtype=np.int64)
    F = H.T @ H + Um.T @ Um + Ya.T @ Ya
    return 3 if np.array_equal(F, 56 * np.eye(24, dtype=np.int64)) else 2


def run(k):
    ctx = OD.build(k); t1 = time.time()
    nodes, loc, complete, c3 = OD.dfs_nb3(ctx, 0)
    t2 = time.time()
    WORDS = set(OD.DAT["golay_words"]) if "golay_words" in OD.DAT else None
    cnt = {"joint_star_sums": 0, "gram_T": 0, "frame_identity": 0}; surv = []; frames = []
    for P in loc:
        a = [sum(ctx["Ms"][c][1][i] for c in P) for i in range(24)]          # Lemma Z re-check (Python)
        assert sum(1 << i for i in range(24) if a[i] % 4 == 3) in OD.WORDS and sum(a) % 8 == 0
        slots, sols = J.joint_fast(ctx, P)
        rec_ = {"M": [ctx["Ms"][c][1] for c in P], "joint_solutions": len(sols)}
        if sols:
            cnt["joint_star_sums"] += 1
            lev = [full_check(ctx, P, slots, s) for s in sols]; rec_["levels"] = lev
            if max(lev) >= 2: cnt["gram_T"] += 1
            if max(lev) >= 3: cnt["frame_identity"] += 1; frames.append(rec_)
        surv.append(rec_)
    t3 = time.time()
    counts = {"leaves": c3["leaves"], "lemmaZ": c3["lemmaZ"], "local_star_sums": c3["local_star_sums"], **cnt}
    res = {"class": k, "eligible_words": ctx["nW"], "signed_octads": ctx["nM"], "nodes_per_depth": nodes, "complete": complete,
           "counts": counts, "survivors": surv[:500], "frames": frames, "engine": "nb3 + numba joint (o24_run_fast.py)",
           "verdict": ("INCOMPLETE (node limit)" if not complete else "FRAME FOUND" if frames else
                       "EMPTY (no local star sums)" if not counts["local_star_sums"] else
                       "EMPTY (no joint star sums)" if not counts["joint_star_sums"] else "joint star sums survive; (F) fails at T or identity"),
           "secs_build": ctx["secs_build"], "secs_dfs": round(t2 - t1, 1), "secs_stage2": round(t3 - t2, 1)}
    if complete:
        os.makedirs(os.path.join(OD.LAB, "data", "finishC", "o24_dfs"), exist_ok=True)      # absent from the cloud package (v3 CI 02/10)
        json.dump(res, open(os.path.join(OD.LAB, "data", "finishC", "o24_dfs", "class_%03d.json" % k), "w"))
    print("O24 class %d: nodes %s, counts %s, %s, dfs %.1fs stage2 %.1fs [nb3+joint_nb]" % (k, nodes, counts, res["verdict"], res["secs_dfs"], res["secs_stage2"]), flush=True)
    return res


if __name__ == "__main__":
    for a in sys.argv[1:]: run(int(a))
