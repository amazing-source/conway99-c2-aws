"""Finish line (C), envelope O24 (odd Leech lattice): exact search for the physical frame (F), per (y1, y2) class. This is C2's
implementation, independent of structures' DFS; the two are compared class by class.
Classes: C1's 141 orbit reps (data/finishC/o24_ypairs.json, conway99-c1 48eabf2, confirmed by structures).

Setup, for y_j = a_j / sqrt8 in C1's normal form:
- eligible sign words E (norm-3 vectors s / sqrt8, negative support in Golay), E . a1 = E . a2 = 0, one per line (s[0] = +1);
- signed octads M (+-1 on an octad, even number of -1, one per +- pair, first point +1), M . a1 = M . a2 = 0.
  h = 2M / sqrt8. The (+-4, +-4) type is excluded by the diagonal of (F): it would put 2 > 3/2 there.
For a family P of M's, let v(E, M) = E . M in {0, +-4, +-8}, so that (h, u) = v / 4.

Stage 1: 7 signed octads.
- Pairwise orthogonal.
- Point multiplicity 1 on A = T1 u T2 and 3 off A, from the diagonal of (F).
- Good: no |v| = 8, since (h_c, u_o) is in {0, +-1}.
- (a) For every pair c, d: Same(c,d) = {E : v_c = v_d = +-4, v_e = 0 for the other e} and Opp(c,d) (v_c = -v_d) are non-empty.
  These are u_o for o = e_c + e_d and e_c - e_d.
- (b) star0(c) = {E Good : v_c != 0, v_e = 0 for the other chosen e} has >= 2 (7 - |P|) elements (future partners of c).
  #{E Good : v_e = 0 for all chosen e} >= (7 - |P|)(6 - |P|) (future pairs).
Stage 2, on the stage-1 leaves:
- Lemma Z (C1): a = sum_c M_c satisfies {a = 3 mod 4} in Golay and sum(a) = 0 mod 8.
- (c) STAR SUMS: 3 h_c + sum_o C_co u_o = 0, i.e. sum over the 12 words of c (one Same and one Opp per partner d), each oriented
  so that E . M_c = +4, equals 6 M_c.
  First per c (local), then jointly over the 42 words (each word lies in two stars, and they are distinct lines).
- (d) Every joint solution is checked against the rest of (F): T = -Gram(u) off the diagonal, T^2 + T = 12 I - C^T C, and
  sum h h^T + sum u u^T + sum y y^T = 7 I. A solution passing (d) would be reported as FRAME FOUND.

Enumeration (each family exactly once): candidates are bitsets over the signed octads.
- compat[j] = orthogonal to j, pairwise (a) with j, no common point of A.
- Branch on the point with remaining need r > 0 and the fewest candidates n (key n - r, lowest point on ties). The branch
  picks the smallest-index octad through that point; earlier siblings are excluded from later branches. Saturated points
  remove their octads.
Two engines run the same algorithm and must give identical node counts and leaves on truncated runs (--check):
- dfs_py: reference, Python ints;
- dfs_nb: numba, uint64 arrays, used for the runs.
Output: data/finishC/o24_dfs/class_KKK.json = {class, nodes_per_depth, counts per stage, survivors, verdict}.
Usage: python o24_dfs.py <class> [<class> ...]          (runs run3; env O24_NODE_LIMIT caps the tree, for timing)
       python o24_dfs.py --check <class> <node limit>  (both engines must agree)"""
import sys, os, json, time, itertools
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"): os.environ.setdefault(_v, "1")
import numpy as np
import numba as nb
LAB = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DAT = json.load(open(os.path.join(LAB, "data", "finishC", "o24_ypairs.json")))


def golay_words():
    basis = DAT["golay_basis"]; W = set()
    for mask in range(1 << 12):
        w = 0
        for r in range(12):
            if mask >> r & 1: w ^= basis[r]
        W.add(w)
    assert len(W) == 4096
    return W


WORDS = golay_words(); OCTADS = sorted(w for w in WORDS if bin(w).count("1") == 8); assert len(OCTADS) == 759
BITS = lambda w: [i for i in range(24) if w >> i & 1]
# SUPPORT tables: what is left to cover (need, all entries <= left) must be a sum of `left` octads.
# Key of a need vector with entries in {0, 1, 2}: {need >= 1} | {need = 2} << 24.
PAIRKEY_SET = {(O | Q) | ((O & Q) << 24) for x, O in enumerate(OCTADS) for Q in OCTADS[x:]}
PAIRKEYS = np.array(sorted(PAIRKEY_SET), dtype=np.int64); OCTARR = np.array(OCTADS, dtype=np.int64); OCT_SET = set(OCTADS)
OCT_BY_PT = np.array([[O for O in OCTADS if O >> p & 1] for p in range(24)], dtype=np.int64)       # 24 x 253


def support_ok(need, left):
    """reference: need is a sum of `left` octad supports (checked for left <= 3; for left >= 4 only need <= left)"""
    if max(need) > left: return False
    S = sum(1 << i for i in range(24) if need[i] >= 1); T2 = sum(1 << i for i in range(24) if need[i] >= 2)
    T3 = sum(1 << i for i in range(24) if need[i] >= 3)
    if left == 1: return S in OCT_SET
    if left == 2: return (S | (T2 << 24)) in PAIRKEY_SET
    if left == 3:
        p = (S & -S).bit_length() - 1
        for O in OCT_BY_PT[p]:
            O = int(O)
            if O & ~S or T3 & ~O: continue
            if (((S & ~O) | (T2 & O)) | (((T2 & ~O) | (T3 & O)) << 24)) in PAIRKEY_SET: return True
        return False
    return True


def setup(cl):
    T1, T2, Dd = set(cl["T1"]), set(cl["T2"]), set(cl["D"])
    a1 = [(-3 if i in T1 else 1) for i in range(24)]
    a2 = [(-3 if i in T2 else 1) * (-1 if i in Dd else 1) for i in range(24)]
    assert a1 == cl["a1"] and a2 == cl["a2"]
    for a in (a1, a2): assert sum(1 << i for i in range(24) if a[i] % 4 == 3) in WORDS and sum(a) % 8 == 0 and sum(x * x for x in a) == 56
    assert sum(p * q for p, q in zip(a1, a2)) == 0
    words = []
    for w in sorted(WORDS):
        if w & 1: continue                                              # one per line: s[0] = +1
        s = [(-1 if w >> i & 1 else 1) for i in range(24)]
        if sum(p * q for p, q in zip(s, a1)) == 0 and sum(p * q for p, q in zip(s, a2)) == 0: words.append(s)
    Ms = []
    for O in OCTADS:
        pts = BITS(O)
        for signs in itertools.product((1, -1), repeat=7):              # first point +1 (one per +- pair), even number of -1
            eps = (1,) + signs
            if eps.count(-1) % 2: continue
            M = [0] * 24
            for i, e in zip(pts, eps): M[i] = e
            if sum(M[i] * a1[i] for i in pts) == 0 and sum(M[i] * a2[i] for i in pts) == 0: Ms.append((O, M))
    return a1, a2, words, Ms


def tobits(row):
    return int.from_bytes(np.packbits(np.asarray(row, dtype=bool), bitorder="little").tobytes(), "little")


def pack64(B):
    """bool matrix (rows x n) -> uint64 matrix (rows x ceil(n/64)), bit j of row r = B[r, j]"""
    B = np.asarray(B, dtype=bool); nw = (B.shape[1] + 63) // 64
    P8 = np.packbits(B, axis=1, bitorder="little")
    P8 = np.concatenate([P8, np.zeros((B.shape[0], nw * 8 - P8.shape[1]), dtype=np.uint8)], axis=1)
    return np.ascontiguousarray(P8).view("<u8").astype(np.uint64).reshape(B.shape[0], nw)


def ones(x):
    while x:
        low = x & -x; yield low.bit_length() - 1; x ^= low


def build(k):
    """per class: signed octads, words, and the bitsets (Python ints and uint64 arrays)"""
    t0 = time.time()
    cl = DAT["orbits"][k]; a1, a2, words, Ms = setup(cl); nW, nM = len(words), len(Ms)
    A = sorted(set(cl["T1"]) | set(cl["T2"])); target = [1 if i in A else 3 for i in range(24)]
    Wm = np.array(words, dtype=np.int32); Mm = np.array([m for _, m in Ms], dtype=np.int32)
    V = Mm @ Wm.T                                                       # nM x nW, entries in {0, +-4, +-8}
    assert set(np.unique(V)) <= {0, 4, -4, 8, -8}
    Pf = (V == 4).astype(np.float32); Nf = (V == -4).astype(np.float32)
    SA = np.array([[O >> i & 1 for i in A] for O, _ in Ms], dtype=np.float32)
    CB = np.zeros((nM, nM), dtype=bool)
    for s in range(0, nM, 512):
        e = min(nM, s + 512)
        CB[s:e] = ((Mm[s:e] @ Mm.T) == 0) & ((Pf[s:e] @ Pf.T + Nf[s:e] @ Nf.T) > 0.5) & ((Pf[s:e] @ Nf.T + Nf[s:e] @ Pf.T) > 0.5) \
            & ((SA[s:e] @ SA.T) < 0.5)
    TH = np.array([[(O >> i & 1) == 1 for O, _ in Ms] for i in range(24)])
    mats = {"Z": V == 0, "Pp": V == 4, "Pn": V == -4, "Bd": np.abs(V) == 8}
    mats["NZ"] = mats["Pp"] | mats["Pn"]
    ctx = {"k": k, "a1": a1, "a2": a2, "words": words, "Ms": Ms, "nW": nW, "nM": nM, "target": target,
           "supp": [BITS(O) for O, _ in Ms], "compat": [tobits(r) for r in CB], "through": [tobits(r) for r in TH]}
    for key, m in mats.items(): ctx[key] = [tobits(r) for r in m]
    ctx["u64"] = {"compat": pack64(CB), "through": pack64(TH), **{key: pack64(m) for key, m in mats.items()},
                  "supp": np.array(ctx["supp"], dtype=np.int64), "target": np.array(target, dtype=np.int64),
                  "allM": pack64(np.ones((1, nM), dtype=bool))[0], "allW": pack64(np.ones((1, nW), dtype=bool))[0]}
    ctx["secs_build"] = round(time.time() - t0, 1)
    return ctx


def dfs_py(ctx, node_limit=0, supp_check=True):
    """reference implementation (Python ints as bitsets); returns nodes per depth, leaves (7 indices), complete"""
    compat, through, supp, Z, Pp, Pn, Bd, NZ = (ctx[x] for x in ("compat", "through", "supp", "Z", "Pp", "Pn", "Bd", "NZ"))
    nodes = [0] * 8; leaves = []; stop = [False]

    def rec(P, cand, need, ge1, ge2, good):
        d = len(P); nodes[d] += 1
        if node_limit and sum(nodes) >= node_limit: stop[0] = True
        if stop[0]: return
        if d == 7: leaves.append(list(P)); return
        if supp_check and not support_ok(need, 7 - d): return
        best, bkey = -1, 1 << 30
        for i in range(24):
            r = need[i]
            if r:
                n = (cand & through[i]).bit_count()
                if n < r: return
                if n - r < bkey: best, bkey = i, n - r
        C = cand & through[best]
        for j in ones(C):
            nc = cand & compat[j]; nd = list(need)
            for x in supp[j]:
                nd[x] -= 1
                if not nd[x]: nc &= ~through[x]
            Q = P + [j]; ng = good & ~Bd[j]
            n1 = ge1 | NZ[j]; n2 = ge2 | (ge1 & NZ[j]); left = 7 - len(Q)
            ok = True
            # (a): every chosen pair keeps a Same and an Opp word, orthogonal to the other chosen octads
            for x, y in itertools.combinations(range(len(Q)), 2):
                c, e = Q[x], Q[y]; zo = ng
                for f in Q:
                    if f != c and f != e: zo &= Z[f]
                if not (((Pp[c] & Pp[e]) | (Pn[c] & Pn[e])) & zo) or not (((Pp[c] & Pn[e]) | (Pn[c] & Pp[e])) & zo): ok = False; break
            if ok and left:
                # (b): future partners of c need 2 words each in star0(c); future pairs need 2 words each in the common zero set
                if ((ng & ~n1).bit_count()) < left * (left - 1): ok = False
                else:
                    for c in Q:
                        if (NZ[c] & ng & ~n2).bit_count() < 2 * left: ok = False; break
            if ok: rec(Q, nc, nd, n1, n2, ng)
            cand &= ~(1 << j)
            if stop[0]: return

    rec([], (1 << ctx["nM"]) - 1, list(ctx["target"]), 0, 0, (1 << ctx["nW"]) - 1)
    return nodes, leaves, not stop[0]


U1 = np.uint64(1)


@nb.njit(cache=True, inline="always")
def popc(x):
    x = x - ((x >> np.uint64(1)) & np.uint64(0x5555555555555555))
    x = (x & np.uint64(0x3333333333333333)) + ((x >> np.uint64(2)) & np.uint64(0x3333333333333333))
    x = (x + (x >> np.uint64(4))) & np.uint64(0x0F0F0F0F0F0F0F0F)
    return np.int64((x * np.uint64(0x0101010101010101)) >> np.uint64(56))


@nb.njit(cache=True)
def dfs_kernel(compat, through, supp, Z, Pp, Pn, Bd, NZ, target, allM, allW, node_limit, cap):
    """same algorithm as dfs_py, iterative, uint64 bitsets. Returns (nodes, leaves[:nleaves], complete, overflow)"""
    nMw = compat.shape[1]; nWw = Z.shape[1]
    cand = np.zeros((8, nMw), np.uint64); Cs = np.zeros((8, nMw), np.uint64)
    need = np.zeros((8, 24), np.int64)
    ge1 = np.zeros((8, nWw), np.uint64); ge2 = np.zeros((8, nWw), np.uint64); good = np.zeros((8, nWw), np.uint64)
    P = np.zeros(8, np.int64); curj = np.zeros(8, np.int64); nodes = np.zeros(8, np.int64)
    leaves = np.zeros((cap, 7), np.int64); nleaves = 0; overflow = False
    for w in range(nMw): cand[0, w] = allM[w]
    for w in range(nWw): good[0, w] = allW[w]
    for i in range(24): need[0, i] = target[i]
    total = 0; stop = False; d = 0; action = 0                          # 0 = enter, 1 = next sibling, 2 = pop
    while True:
        if action == 0:
            nodes[d] += 1; total += 1
            if node_limit > 0 and total >= node_limit: stop = True
            if stop:
                action = 2; continue
            if d == 7:
                if nleaves < cap:
                    for x in range(7): leaves[nleaves, x] = P[x]
                    nleaves += 1
                else: overflow = True
                action = 2; continue
            best = -1; bkey = 1 << 30; pruned = False
            for i in range(24):
                r = need[d, i]
                if r > 0:
                    n = 0
                    for w in range(nMw): n += popc(cand[d, w] & through[i, w])
                    if n < r:
                        pruned = True; break
                    if n - r < bkey:
                        best = i; bkey = n - r
            if pruned:
                action = 2; continue
            for w in range(nMw): Cs[d, w] = cand[d, w] & through[best, w]
            action = 1; continue
        elif action == 1:
            j = -1
            for w in range(nMw):
                x = Cs[d, w]
                if x != 0:
                    low = x & (~x + U1)
                    j = w * 64 + popc(low - U1); Cs[d, w] = x ^ low
                    break
            if j < 0:
                action = 2; continue
            curj[d] = j; P[d] = j
            e1 = d + 1
            for w in range(nMw): cand[e1, w] = cand[d, w] & compat[j, w]
            for i in range(24): need[e1, i] = need[d, i]
            for q in range(8):
                x = supp[j, q]; need[e1, x] -= 1
                if need[e1, x] == 0:
                    for w in range(nMw): cand[e1, w] &= ~through[x, w]
            for w in range(nWw):
                good[e1, w] = good[d, w] & ~Bd[j, w]
                ge1[e1, w] = ge1[d, w] | NZ[j, w]
                ge2[e1, w] = ge2[d, w] | (ge1[d, w] & NZ[j, w])
            left = 7 - e1; ok = True
            for x in range(e1):
                if not ok: break
                for y in range(x + 1, e1):
                    c = P[x]; e = P[y]; same = np.uint64(0); opp = np.uint64(0)
                    for w in range(nWw):
                        zo = good[e1, w]
                        for f in range(e1):
                            if f != x and f != y: zo &= Z[P[f], w]
                        same |= ((Pp[c, w] & Pp[e, w]) | (Pn[c, w] & Pn[e, w])) & zo
                        opp |= ((Pp[c, w] & Pn[e, w]) | (Pn[c, w] & Pp[e, w])) & zo
                    if same == 0 or opp == 0:
                        ok = False; break
            if ok and left > 0:
                n = 0
                for w in range(nWw): n += popc(good[e1, w] & ~ge1[e1, w])
                if n < left * (left - 1): ok = False
                else:
                    for x in range(e1):
                        c = P[x]; n = 0
                        for w in range(nWw): n += popc(NZ[c, w] & good[e1, w] & ~ge2[e1, w])
                        if n < 2 * left:
                            ok = False; break
            if ok:
                d = e1; action = 0; continue
            cand[d, j >> 6] &= ~(U1 << np.uint64(j & 63))
            action = 1; continue
        else:
            if d == 0: break
            d -= 1; j = curj[d]
            cand[d, j >> 6] &= ~(U1 << np.uint64(j & 63))
            action = 2 if stop else 1
    return nodes, leaves[:nleaves], not stop, overflow


@nb.njit(cache=True)
def dfs_kernel2(compat, through, supp, Z, Pp, Pn, Bd, NZ, target, allM, allW, node_limit, cap):
    """dfs_kernel with the same tree, faster: the word-level checks (a), (b) run before the candidate bitset is built, and every
    depth keeps the list of its non-zero candidate words (in increasing order), so the bitset loops skip empty words."""
    nMw = compat.shape[1]; nWw = Z.shape[1]
    cand = np.zeros((8, nMw), np.uint64); Cs = np.zeros((8, nMw), np.uint64)
    nzw = np.zeros((8, nMw), np.int64); nnz = np.zeros(8, np.int64)
    need = np.zeros((8, 24), np.int64)
    ge1 = np.zeros((8, nWw), np.uint64); ge2 = np.zeros((8, nWw), np.uint64); good = np.zeros((8, nWw), np.uint64)
    P = np.zeros(8, np.int64); curj = np.zeros(8, np.int64); nodes = np.zeros(8, np.int64)
    leaves = np.zeros((cap, 7), np.int64); nleaves = 0; overflow = False
    for w in range(nMw):
        cand[0, w] = allM[w]; nzw[0, w] = w
    nnz[0] = nMw
    for w in range(nWw): good[0, w] = allW[w]
    for i in range(24): need[0, i] = target[i]
    total = 0; stop = False; d = 0; action = 0                          # 0 = enter, 1 = next sibling, 2 = pop
    while True:
        if action == 0:
            nodes[d] += 1; total += 1
            if node_limit > 0 and total >= node_limit: stop = True
            if stop:
                action = 2; continue
            if d == 7:
                if nleaves < cap:
                    for x in range(7): leaves[nleaves, x] = P[x]
                    nleaves += 1
                else: overflow = True
                action = 2; continue
            best = -1; bkey = 1 << 30; pruned = False
            for i in range(24):
                r = need[d, i]
                if r > 0:
                    n = 0
                    for t in range(nnz[d]):
                        w = nzw[d, t]; n += popc(cand[d, w] & through[i, w])
                    if n < r:
                        pruned = True; break
                    if n - r < bkey:
                        best = i; bkey = n - r
            if pruned:
                action = 2; continue
            for t in range(nnz[d]):
                w = nzw[d, t]; Cs[d, w] = cand[d, w] & through[best, w]
            curj[d] = 0                                                  # position in the word list for the sibling scan
            action = 1; continue
        elif action == 1:
            j = -1
            while curj[d] < nnz[d]:
                w = nzw[d, curj[d]]; x = Cs[d, w]
                if x != 0:
                    low = x & (~x + U1)
                    j = w * 64 + popc(low - U1); Cs[d, w] = x ^ low
                    break
                curj[d] += 1
            if j < 0:
                action = 2; continue
            P[d] = j
            e1 = d + 1
            for w in range(nWw):
                good[e1, w] = good[d, w] & ~Bd[j, w]
                ge1[e1, w] = ge1[d, w] | NZ[j, w]
                ge2[e1, w] = ge2[d, w] | (ge1[d, w] & NZ[j, w])
            left = 7 - e1; ok = True
            for x in range(e1):
                if not ok: break
                for y in range(x + 1, e1):
                    c = P[x]; e = P[y]; same = np.uint64(0); opp = np.uint64(0)
                    for w in range(nWw):
                        zo = good[e1, w]
                        for f in range(e1):
                            if f != x and f != y: zo &= Z[P[f], w]
                        same |= ((Pp[c, w] & Pp[e, w]) | (Pn[c, w] & Pn[e, w])) & zo
                        opp |= ((Pp[c, w] & Pn[e, w]) | (Pn[c, w] & Pp[e, w])) & zo
                    if same == 0 or opp == 0:
                        ok = False; break
            if ok and left > 0:
                n = 0
                for w in range(nWw): n += popc(good[e1, w] & ~ge1[e1, w])
                if n < left * (left - 1): ok = False
                else:
                    for x in range(e1):
                        c = P[x]; n = 0
                        for w in range(nWw): n += popc(NZ[c, w] & good[e1, w] & ~ge2[e1, w])
                        if n < 2 * left:
                            ok = False; break
            if ok:
                for i in range(24): need[e1, i] = need[d, i]
                cnt = 0
                for t in range(nnz[d]):
                    w = nzw[d, t]; v = cand[d, w] & compat[j, w]
                    if v != 0:
                        cand[e1, w] = v; nzw[e1, cnt] = w; cnt += 1
                nnz[e1] = cnt
                for q in range(8):
                    x = supp[j, q]; need[e1, x] -= 1
                    if need[e1, x] == 0:
                        for t in range(cnt):
                            w = nzw[e1, t]; cand[e1, w] &= ~through[x, w]
                d = e1; action = 0; continue
            cand[d, j >> 6] &= ~(U1 << np.uint64(j & 63))
            action = 1; continue
        else:
            if d == 0: break
            d -= 1; j = P[d]
            cand[d, j >> 6] &= ~(U1 << np.uint64(j & 63))
            action = 2 if stop else 1
    return nodes, leaves[:nleaves], not stop, overflow


@nb.njit(cache=True)
def support_ok_nb(need_row, left, pairkeys, octarr, octbypt):
    """= support_ok"""
    S = 0; T2 = 0; T3 = 0
    for i in range(24):
        r = need_row[i]
        if r > left: return False
        if r >= 1: S |= 1 << i
        if r >= 2: T2 |= 1 << i
        if r >= 3: T3 |= 1 << i
    if left == 1:
        k = np.searchsorted(octarr, S)
        return k < len(octarr) and octarr[k] == S
    if left == 2:
        key = S | (T2 << 24); k = np.searchsorted(pairkeys, key)
        return k < len(pairkeys) and pairkeys[k] == key
    if left == 3:
        p = 0
        while not (S >> p) & 1: p += 1
        for t in range(octbypt.shape[1]):
            O = octbypt[p, t]
            if (O & ~S) != 0 or (T3 & ~O) != 0: continue
            key = ((S & ~O) | (T2 & O)) | (((T2 & ~O) | (T3 & O)) << 24)
            k = np.searchsorted(pairkeys, key)
            if k < len(pairkeys) and pairkeys[k] == key: return True
        return False
    return True


@nb.njit(cache=True)
def leaf_checks_nb(P, Mv, Wv, V, Z, Pp, Pn, allW, gbasis, slots, slen, part, pos):
    """stage 2 in numba on one leaf: returns 0 (Lemma Z fails), 1 (Lemma Z passes, some local star sum fails), 2 (all 7 local
    star sums pass). Same tests as stage2's lemma Z and local_ok."""
    nWw = Z.shape[1]
    a = np.zeros(24, np.int64)
    for x in range(7):
        for i in range(24): a[i] += Mv[P[x], i]
    w3 = 0; sa = 0
    for i in range(24):
        sa += a[i]
        if ((a[i] % 4) + 4) % 4 == 3: w3 |= 1 << i
    if sa % 8 != 0: return 0
    for b in range(gbasis.shape[0]):                                     # the Golay code is self-dual
        v = w3 & gbasis[b]; par = 0
        while v:
            v &= v - 1; par ^= 1
        if par: return 0
    for x in range(7):
        c = P[x]; ns = 0
        for y in range(7):
            if y == x: continue
            d = P[y]
            for kd in range(2):
                L = 0
                for w in range(nWw):
                    zo = allW[w]
                    for f in range(7):
                        if f != x and f != y: zo &= Z[P[f], w]
                    if kd == 0: s = ((Pp[c, w] & Pp[d, w]) | (Pn[c, w] & Pn[d, w])) & zo
                    else: s = ((Pp[c, w] & Pn[d, w]) | (Pn[c, w] & Pp[d, w])) & zo
                    while s != 0:
                        low = s & (~s + U1); slots[ns, L] = w * 64 + popc(low - U1); L += 1; s ^= low
                slen[ns] = L; ns += 1
        # order the 12 slots by size (stable), then DFS with coordinate bounds
        order = np.argsort(slen[:12], kind="mergesort")
        for i in range(24): part[0, i] = 0
        lvl = 0; entering = True; found = False
        while True:
            if entering:                                                 # bounds on part[lvl] with 12 - lvl words to come
                r = 12 - lvl; okb = True
                for q in range(24):
                    dl = 6 * Mv[c, q] - part[lvl, q]
                    if dl > r or dl < -r or (dl - r) % 2 != 0:
                        okb = False; break
                if okb and lvl == 12:
                    found = True; break
                if not okb:
                    lvl -= 1
                    if lvl < 0: break
                    entering = False; continue
                pos[lvl] = -1; entering = False
            sl = order[lvl]; pos[lvl] += 1                               # next word for the slot of level lvl
            if pos[lvl] >= slen[sl]:
                lvl -= 1
                if lvl < 0: break
                continue
            t = slots[sl, pos[lvl]]; sg = 1 if V[c, t] > 0 else -1
            for q in range(24): part[lvl + 1, q] = part[lvl, q] + sg * Wv[t, q]
            lvl += 1; entering = True
        if not found: return 1
    return 2


@nb.njit(cache=True)
def dfs_kernel3(compat, through, supp, Z, Pp, Pn, Bd, NZ, target, allM, allW, node_limit, cap,
                pairkeys, octarr, octbypt, Mv, Wv, V, gbasis):
    """dfs_kernel2 + the support check at every node (= dfs_py with supp_check) + stage 2 (Lemma Z, local star sums) at the
    leaves. Keeps only the leaves passing every local star sum. Returns (nodes, survivors, complete, overflow, counts)."""
    nMw = compat.shape[1]; nWw = Z.shape[1]; nW = Wv.shape[0]
    cand = np.zeros((8, nMw), np.uint64); Cs = np.zeros((8, nMw), np.uint64)
    nzw = np.zeros((8, nMw), np.int64); nnz = np.zeros(8, np.int64)
    need = np.zeros((8, 24), np.int64)
    ge1 = np.zeros((8, nWw), np.uint64); ge2 = np.zeros((8, nWw), np.uint64); good = np.zeros((8, nWw), np.uint64)
    P = np.zeros(8, np.int64); curj = np.zeros(8, np.int64); nodes = np.zeros(8, np.int64)
    leaves = np.zeros((cap, 7), np.int64); nleaves = 0; overflow = False
    counts = np.zeros(3, np.int64)                                       # leaves, Lemma Z, all local star sums
    slots = np.zeros((12, nW), np.int64); slen = np.zeros(12, np.int64); part = np.zeros((13, 24), np.int64); pos = np.zeros(13, np.int64)
    for w in range(nMw):
        cand[0, w] = allM[w]; nzw[0, w] = w
    nnz[0] = nMw
    for w in range(nWw): good[0, w] = allW[w]
    for i in range(24): need[0, i] = target[i]
    total = 0; stop = False; d = 0; action = 0                          # 0 = enter, 1 = next sibling, 2 = pop
    while True:
        if action == 0:
            nodes[d] += 1; total += 1
            if node_limit > 0 and total >= node_limit: stop = True
            if stop:
                action = 2; continue
            if d == 7:
                counts[0] += 1
                res = leaf_checks_nb(P, Mv, Wv, V, Z, Pp, Pn, allW, gbasis, slots, slen, part, pos)
                if res >= 1: counts[1] += 1
                if res == 2:
                    counts[2] += 1
                    if nleaves < cap:
                        for x in range(7): leaves[nleaves, x] = P[x]
                        nleaves += 1
                    else: overflow = True
                action = 2; continue
            if not support_ok_nb(need[d], 7 - d, pairkeys, octarr, octbypt):
                action = 2; continue
            best = -1; bkey = 1 << 30; pruned = False
            for i in range(24):
                r = need[d, i]
                if r > 0:
                    n = 0
                    for t in range(nnz[d]):
                        w = nzw[d, t]; n += popc(cand[d, w] & through[i, w])
                    if n < r:
                        pruned = True; break
                    if n - r < bkey:
                        best = i; bkey = n - r
            if pruned:
                action = 2; continue
            for t in range(nnz[d]):
                w = nzw[d, t]; Cs[d, w] = cand[d, w] & through[best, w]
            curj[d] = 0
            action = 1; continue
        elif action == 1:
            j = -1
            while curj[d] < nnz[d]:
                w = nzw[d, curj[d]]; x = Cs[d, w]
                if x != 0:
                    low = x & (~x + U1)
                    j = w * 64 + popc(low - U1); Cs[d, w] = x ^ low
                    break
                curj[d] += 1
            if j < 0:
                action = 2; continue
            P[d] = j
            e1 = d + 1
            for w in range(nWw):
                good[e1, w] = good[d, w] & ~Bd[j, w]
                ge1[e1, w] = ge1[d, w] | NZ[j, w]
                ge2[e1, w] = ge2[d, w] | (ge1[d, w] & NZ[j, w])
            left = 7 - e1; ok = True
            for x in range(e1):
                if not ok: break
                for y in range(x + 1, e1):
                    c = P[x]; e = P[y]; same = np.uint64(0); opp = np.uint64(0)
                    for w in range(nWw):
                        zo = good[e1, w]
                        for f in range(e1):
                            if f != x and f != y: zo &= Z[P[f], w]
                        same |= ((Pp[c, w] & Pp[e, w]) | (Pn[c, w] & Pn[e, w])) & zo
                        opp |= ((Pp[c, w] & Pn[e, w]) | (Pn[c, w] & Pp[e, w])) & zo
                    if same == 0 or opp == 0:
                        ok = False; break
            if ok and left > 0:
                n = 0
                for w in range(nWw): n += popc(good[e1, w] & ~ge1[e1, w])
                if n < left * (left - 1): ok = False
                else:
                    for x in range(e1):
                        c = P[x]; n = 0
                        for w in range(nWw): n += popc(NZ[c, w] & good[e1, w] & ~ge2[e1, w])
                        if n < 2 * left:
                            ok = False; break
            if ok:
                for i in range(24): need[e1, i] = need[d, i]
                cnt = 0
                for t in range(nnz[d]):
                    w = nzw[d, t]; v = cand[d, w] & compat[j, w]
                    if v != 0:
                        cand[e1, w] = v; nzw[e1, cnt] = w; cnt += 1
                nnz[e1] = cnt
                for q in range(8):
                    x = supp[j, q]; need[e1, x] -= 1
                    if need[e1, x] == 0:
                        for t in range(cnt):
                            w = nzw[e1, t]; cand[e1, w] &= ~through[x, w]
                d = e1; action = 0; continue
            cand[d, j >> 6] &= ~(U1 << np.uint64(j & 63))
            action = 1; continue
        else:
            if d == 0: break
            d -= 1; j = P[d]
            cand[d, j >> 6] &= ~(U1 << np.uint64(j & 63))
            action = 2 if stop else 1
    return nodes, leaves[:nleaves], not stop, overflow, counts


def dfs_nb3(ctx, node_limit=0, cap=2_000_000):
    """kernel 3: returns nodes, the leaves passing Lemma Z and all local star sums, complete, counts"""
    u = ctx["u64"]
    if "Mv" not in u:
        u["Mv"] = np.array([m for _, m in ctx["Ms"]], dtype=np.int64); u["Wv"] = np.array(ctx["words"], dtype=np.int64)
        u["V"] = u["Mv"] @ u["Wv"].T; u["gbasis"] = np.array(DAT["golay_basis"], dtype=np.int64)
    nodes, leaves, complete, overflow, counts = dfs_kernel3(u["compat"], u["through"], u["supp"], u["Z"], u["Pp"], u["Pn"], u["Bd"],
                                                            u["NZ"], u["target"], u["allM"], u["allW"], node_limit, cap,
                                                            PAIRKEYS, OCTARR, OCT_BY_PT, u["Mv"], u["Wv"], u["V"], u["gbasis"])
    assert not overflow, "leaf buffer overflow"
    return ([int(x) for x in nodes], [[int(x) for x in L] for L in leaves], bool(complete),
            {"leaves": int(counts[0]), "lemmaZ": int(counts[1]), "local_star_sums": int(counts[2])})


def dfs_nb(ctx, node_limit=0, cap=2_000_000, kernel=None):
    u = ctx["u64"]; kernel = kernel or dfs_kernel
    nodes, leaves, complete, overflow = kernel(u["compat"], u["through"], u["supp"], u["Z"], u["Pp"], u["Pn"], u["Bd"], u["NZ"],
                                               u["target"], u["allM"], u["allW"], node_limit, cap)
    assert not overflow, "leaf buffer overflow"
    return [int(x) for x in nodes], [[int(x) for x in L] for L in leaves], bool(complete)


def stage2(ctx, leaves):
    """Lemma Z, star sums (local, then joint), rest of (F), on the stage-1 leaves"""
    words, Ms, Z, Pp, Pn, a1, a2 = (ctx[x] for x in ("words", "Ms", "Z", "Pp", "Pn", "a1", "a2")); ALLW = (1 << ctx["nW"]) - 1
    cnt = {"leaves": 0, "lemmaZ": 0, "local_star_sums": 0, "joint_star_sums": 0, "gram_T": 0, "frame_identity": 0}
    surv = []; frames = []

    def pair_sets(P):
        """Same(c,d), Opp(c,d) restricted to words with v_e = 0 for the other e in P"""
        out = {}
        for x, y in itertools.combinations(range(len(P)), 2):
            c, d = P[x], P[y]; zo = ALLW
            for e in P:
                if e != c and e != d: zo &= Z[e]
            out[(x, y)] = (((Pp[c] & Pp[d]) | (Pn[c] & Pn[d])) & zo, ((Pp[c] & Pn[d]) | (Pn[c] & Pp[d])) & zo)
        return out

    def oriented(t, c):
        w = words[t]; m = Ms[c][1]; v = sum(w[i] * m[i] for i in range(24))
        return [x if v > 0 else -x for x in w]

    def local_ok(P, x, S):
        """star sum of c = P[x]: one word per slot (Same/Opp with each partner), oriented towards M_c, summing to 6 M_c"""
        c = P[x]; tgt = [6 * v for v in Ms[c][1]]
        slots = []
        for y in range(7):
            if y == x: continue
            for st in S[(min(x, y), max(x, y))]: slots.append([oriented(t, c) for t in ones(st)])
        slots.sort(key=len); n = len(slots)

        def go(i, part):
            r = n - i
            for q in range(24):
                dlt = tgt[q] - part[q]
                if dlt > r or dlt < -r or (dlt - r) % 2: return False
            if i == n: return True
            return any(go(i + 1, [p + q for p, q in zip(part, v)]) for v in slots[i])
        return go(0, [0] * 24)

    def joint(P, S):
        """all joint choices of the 42 words (Same and Opp for each pair) with every star sum = 6 M_c (capped at 1000)"""
        slots = []                                                      # (x, y, kind, [word index])
        for (x, y), (ss, os_) in sorted(S.items()): slots += [(x, y, 0, list(ones(ss))), (x, y, 1, list(ones(os_)))]
        slots.sort(key=lambda s: len(s[3]))
        rem = [12] * 7; part = [[0] * 24 for _ in range(7)]; tgt = [[6 * v for v in Ms[c][1]] for c in P]
        orient = {}
        for x, y, kd, ts in slots:
            for t in ts: orient[(t, x)] = oriented(t, P[x]); orient[(t, y)] = oriented(t, P[y])
        sols = []; choice = [None] * len(slots)

        def feas(x):
            r = rem[x]; pt = part[x]; tg = tgt[x]
            for q in range(24):
                dlt = tg[q] - pt[q]
                if dlt > r or dlt < -r or (dlt - r) % 2: return False
            return True

        def go(i):
            if len(sols) >= 1000: return
            if i == len(slots): sols.append(list(choice)); return
            x, y, kd, ts = slots[i]
            for t in ts:
                if t in choice[:i]: continue                            # the 42 u's are distinct lines
                ox, oy = orient[(t, x)], orient[(t, y)]
                for q in range(24): part[x][q] += ox[q]; part[y][q] += oy[q]
                rem[x] -= 1; rem[y] -= 1; choice[i] = t
                if feas(x) and feas(y): go(i + 1)
                for q in range(24): part[x][q] -= ox[q]; part[y][q] -= oy[q]
                rem[x] += 1; rem[y] += 1; choice[i] = None
        go(0)
        return slots, sols

    def full_check(P, slots, sol):
        """rest of (F) for one joint solution. u_o = the word oriented towards M_x, so (h_x, u_o) = +1: C_xo = -1, C_yo = -(h_y, u_o)"""
        U, Cm = [], np.zeros((7, 42), dtype=np.int64)
        for o, ((x, y, kd, ts), t) in enumerate(zip(slots, sol)):
            u = oriented(t, P[x]); U.append(u)
            vy = sum(u[i] * Ms[P[y]][1][i] for i in range(24)) // 4
            Cm[x, o] = -1; Cm[y, o] = -vy
        Um = np.array(U, dtype=np.int64)                                # rows: sqrt8 u_o
        G = Um @ Um.T                                                   # 8 (u, u')
        off = G - np.diag(np.diag(G))
        if not np.all(np.isin(off, (0, 8, -8))): return 0
        T = -off // 8
        if not np.array_equal(T @ T + T, 12 * np.eye(42, dtype=np.int64) - Cm.T @ Cm): return 1
        H = np.array([Ms[c][1] for c in P], dtype=np.int64) * 2
        Ya = np.array([a1, a2], dtype=np.int64)
        F = H.T @ H + Um.T @ Um + Ya.T @ Ya                             # 8 * sum f f^T
        return 3 if np.array_equal(F, 56 * np.eye(24, dtype=np.int64)) else 2

    for P in leaves:
        cnt["leaves"] += 1
        a = [sum(Ms[c][1][i] for c in P) for i in range(24)]
        if not (sum(1 << i for i in range(24) if a[i] % 4 == 3) in WORDS and sum(a) % 8 == 0): continue
        cnt["lemmaZ"] += 1
        S = pair_sets(P)
        if not all(local_ok(P, x, S) for x in range(7)): continue
        cnt["local_star_sums"] += 1
        slots, sols = joint(P, S)
        rec_ = {"M": [Ms[c][1] for c in P], "joint_solutions": len(sols)}
        if sols:
            cnt["joint_star_sums"] += 1
            lev = [full_check(P, slots, s) for s in sols]
            rec_["levels"] = lev
            if max(lev) >= 2: cnt["gram_T"] += 1
            if max(lev) >= 3:
                cnt["frame_identity"] += 1; frames.append(rec_)
        surv.append(rec_)
    return cnt, surv, frames


def run(k, node_limit=0, engine="nb", quiet=False, save=True):
    ctx = build(k); t1 = time.time()
    nodes, leaves, complete = (dfs_nb if engine == "nb" else dfs_py)(ctx, node_limit)
    t2 = time.time(); cnt, surv, frames = stage2(ctx, leaves); t3 = time.time()
    res = {"class": k, "eligible_words": ctx["nW"], "signed_octads": ctx["nM"], "nodes_per_depth": nodes, "complete": complete,
           "counts": cnt, "survivors": surv[:500], "frames": frames, "engine": engine,
           "verdict": ("INCOMPLETE (node limit)" if not complete else "FRAME FOUND" if frames else
                       "EMPTY (no local star sums)" if not cnt["local_star_sums"] else
                       "EMPTY (no joint star sums)" if not cnt["joint_star_sums"] else "joint star sums survive; (F) fails at T or identity"),
           "secs_build": ctx["secs_build"], "secs_dfs": round(t2 - t1, 1), "secs_stage2": round(t3 - t2, 1)}
    if save and complete and not node_limit:
        os.makedirs(os.path.join(LAB, "data", "finishC", "o24_dfs"), exist_ok=True)
        json.dump(res, open(os.path.join(LAB, "data", "finishC", "o24_dfs", "class_%03d.json" % k), "w"))
    if not quiet:
        print("O24 class %d: words %d, signed octads %d, nodes %s, counts %s, %s, build %.1fs dfs %.1fs stage2 %.1fs" %
              (k, ctx["nW"], ctx["nM"], nodes, cnt, res["verdict"], ctx["secs_build"], res["secs_dfs"], res["secs_stage2"]), flush=True)
    return res


def run3(k, node_limit=0, quiet=False, save=True):
    """kernel 3 (support cut; Lemma Z and local star sums inside numba), then the Python stage 2 on the leaves that pass all local
    star sums: it re-checks them (must agree) and runs the joint star sums and the rest of (F)"""
    ctx = build(k); t1 = time.time()
    nodes, loc, complete, c3 = dfs_nb3(ctx, node_limit)
    t2 = time.time(); cnt, surv, frames = stage2(ctx, loc); t3 = time.time()
    assert cnt["leaves"] == cnt["lemmaZ"] == cnt["local_star_sums"] == len(loc) == c3["local_star_sums"], "numba and Python stage 2 disagree"
    counts = {"leaves": c3["leaves"], "lemmaZ": c3["lemmaZ"], "local_star_sums": c3["local_star_sums"], "joint_star_sums": cnt["joint_star_sums"],
              "gram_T": cnt["gram_T"], "frame_identity": cnt["frame_identity"]}
    res = {"class": k, "eligible_words": ctx["nW"], "signed_octads": ctx["nM"], "nodes_per_depth": nodes, "complete": complete,
           "counts": counts, "survivors": surv[:500], "frames": frames, "engine": "nb3 (support cut, numba stage 2) + Python joint stage",
           "verdict": ("INCOMPLETE (node limit)" if not complete else "FRAME FOUND" if frames else
                       "EMPTY (no local star sums)" if not counts["local_star_sums"] else
                       "EMPTY (no joint star sums)" if not counts["joint_star_sums"] else "joint star sums survive; (F) fails at T or identity"),
           "secs_build": ctx["secs_build"], "secs_dfs": round(t2 - t1, 1), "secs_stage2": round(t3 - t2, 1)}
    if save and complete and not node_limit:
        os.makedirs(os.path.join(LAB, "data", "finishC", "o24_dfs"), exist_ok=True)
        json.dump(res, open(os.path.join(LAB, "data", "finishC", "o24_dfs", "class_%03d.json" % k), "w"))
    if not quiet:
        print("O24 class %d: words %d, signed octads %d, nodes %s, counts %s, %s, build %.1fs dfs %.1fs stage2 %.1fs [nb3]" %
              (k, ctx["nW"], ctx["nM"], nodes, counts, res["verdict"], ctx["secs_build"], res["secs_dfs"], res["secs_stage2"]), flush=True)
    return res


if __name__ == "__main__":
    args = sys.argv[1:]
    if args and args[0] == "--check":                                  # --check <class> <node limit>: both engines must agree
        k, lim = int(args[1]), int(args[2]); ctx = build(k)
        t0 = time.time(); r1 = dfs_py(ctx, lim); t1 = time.time(); r2 = dfs_nb(ctx, lim); t2 = time.time()
        print("class %d limit %d: py nodes %s leaves %d (%.1fs) | nb nodes %s leaves %d (%.1fs) | identical: %s" %
              (k, lim, r1[0], len(r1[1]), t1 - t0, r2[0], len(r2[1]), t2 - t1, r1 == r2), flush=True)
    else:
        lim = int(os.environ.get("O24_NODE_LIMIT", "0"))
        for a in args: run3(int(a), lim)                                # kernel 3 (checked against kernel 1 and dfs_py)
