"""Package v3 calibration (C2, 2026-10-02): proves that a machine computes the two new job kinds exactly as the lab.
  python calib_v3.py make    (lab, at package build)  -> calib_reference/v3_reference.json
  python calib_v3.py check   (machine, after the v1/v2 calibrations) -> prints EQUIVALENT (exit 0) or DIFFERENT (exit 1)
Three deterministic checks:
  (a) golay_pairs: job slice 001:<GK>:<GN> run by scripts/golay_pairs_job.py (verdicts, non-excluded list, range, pair-file sha, code sha);
  (b) O24 kernel 3 on class 0 with a node limit of 300,000 (nodes per depth, leaves passing Lemma Z / local star sums);
  (c) O24 numba joint star sums: planted solutions on 4 saved local survivors of class 21 (identical solution lists)."""
import os, sys, json, subprocess, random
ROOT = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(ROOT, "scripts"))
for v_ in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMBA_NUM_THREADS"): os.environ.setdefault(v_, "1")
GK, GN = 5, 4000
REF = os.path.join(ROOT, "calib_reference", "v3_reference.json")


def compute():
    out = {}
    os.makedirs(os.path.join(ROOT, "calib"), exist_ok=True)
    res = os.path.join(ROOT, "calib", "v3_golay.jsonl")
    if os.path.exists(res): os.remove(res)
    env = {k: v for k, v in os.environ.items() if not k.startswith("FD_")}
    env.update(FD_LEMMA_U="1", FD_SYM="1")
    subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "golay_pairs_job.py"), "1", str(GK), str(GN), res], env=env, cwd=ROOT,
                   check=True, capture_output=True)
    r = json.loads(open(res).read().strip().splitlines()[-1])
    out["golay"] = {k: r[k] for k in ("chunk", "range", "n_pairs", "pairs_total", "pair_files_sha256", "verdicts", "not_excluded", "chunk_ok",
                                      "chunk_done", "code_sha", "node_limit")}
    import o24_dfs as OD
    ctx = OD.build(0)
    nodes, loc, complete, c3 = OD.dfs_nb3(ctx, 300000)
    out["o24_kernel3_class0"] = {"nodes": nodes, "local_survivors": len(loc), "complete": complete, "counts": c3}
    import o24_joint_nb as J
    ctx21 = OD.build(21)
    surv = json.load(open(os.path.join(ROOT, "calib_reference", "o24_c21_survivors.json")))
    idx = {tuple(m): i for i, (_, m) in enumerate(ctx21["Ms"])}
    rng = random.Random(7); planted = []
    import numpy as np
    for s in surv[:4]:
        P = [idx[tuple(m)] for m in s["M"]]
        slots, S = J.build_slots(ctx21, P)
        used = set(); pick = []
        for (x, y, kd, ts) in slots:
            free = [t for t in ts if t not in used]; t = rng.choice(free); used.add(t); pick.append(t)
        Wv = np.array(ctx21["words"], dtype=np.int64); Mv = np.array([ctx21["Ms"][c][1] for c in P], dtype=np.int64); V = Mv @ Wv.T
        tgt = np.zeros((7, 24), np.int64)
        for (x, y, kd, ts), t in zip(slots, pick):
            tgt[x] += (1 if V[x, t] > 0 else -1) * Wv[t]; tgt[y] += (1 if V[y, t] > 0 else -1) * Wv[t]
        _, sols = J.joint_fast(ctx21, P, 1000, tgt)
        planted.append({"P": P, "planted": pick, "solutions": sols, "found": pick in sols})
    out["o24_joint_planted"] = planted
    return out


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "check"
    got = compute()
    if mode == "make":
        json.dump(got, open(REF, "w"), indent=1); print("reference written:", REF)
        sys.exit(0)
    ref = json.load(open(REF))
    diff = [k for k in ref if json.dumps(ref[k], sort_keys=True) != json.dumps(got.get(k), sort_keys=True)]
    ok = not diff and all(p["found"] for p in got["o24_joint_planted"])
    print("EQUIVALENT (golay slice, O24 kernel 3, O24 joint planted)" if ok else "DIFFERENT: %s" % diff)
    sys.exit(0 if ok else 1)
