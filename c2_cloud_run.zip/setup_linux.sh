#!/bin/bash
# Fresh Linux machine -> exact environment (Python version and packages pinned by the package), then run the assigned jobs.
# Usage: bash setup_linux.sh "<run_jobs.py arguments>"
set -euo pipefail
cd "$(dirname "$0")"
curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"
uv python install "$(cat PYTHON_VERSION)"
uv venv --python "$(cat PYTHON_VERSION)" .venv
uv pip install --python .venv/bin/python -r requirements.txt
.venv/bin/python -c "import numpy, numba, scipy, flint, sys; print(sys.version, numpy.__version__, numba.__version__, scipy.__version__)"
.venv/bin/python run_jobs.py $1
