"""Compare two chunk records (JSONL files) on every field that carries the mathematical content. Usage: python verify_equivalence.py A.jsonl B.jsonl
Provenance fields (wall time, timestamps, machine, C1 commit string, producer timing) are reported but not compared."""
import sys, json
KEYS = ["id", "chunk", "n_pairs", "orbits", "sha256", "verdicts", "twin_deferred", "not_excluded", "chunk_ok", "chunk_done", "code_sha", "node_limit",
        "frame_dfs", "telemetry", "sample_search"]
def rec(f):
    R = [json.loads(l) for l in open(f) if l.strip()]; R = [r for r in R if r.get("chunk_ok")] or R; return R[-1]
a, b = rec(sys.argv[1]), rec(sys.argv[2]); bad = [k for k in KEYS if a.get(k) != b.get(k)]
print("EQUIVALENT (all %d content fields identical)" % len(KEYS) if not bad else "DIFFERENT on: %s" % bad)
for k in bad: print("  %s:\n    A=%s\n    B=%s" % (k, str(a.get(k))[:300], str(b.get(k))[:300]))
sys.exit(1 if bad else 0)
