# Route (C) — ce qu'on fait sur CHAQUE machine (C2, 29/09/2026)

Le paquet reproduit exactement le calcul du labo : même moteur octet pour octet, mêmes versions, mêmes données.
`MANIFEST.json` contient le sha256 de chaque fichier, et `run_jobs.py` refuse de tourner si un seul fichier a changé.

Machine : Linux (Ubuntu), **c7a.8xlarge** (32 vrais cœurs), environ 20 Go de disque. Copie `c2_cloud_run.zip` dans le dossier personnel (celui où tu arrives en te connectant), puis :

```bash
python3 -m zipfile -e c2_cloud_run.zip c2_cloud_run && cd c2_cloud_run     # (unzip n'est pas toujours installé)

# 1) Installation + calibration (quelques minutes). La 2e commande DOIT afficher EQUIVALENT, sinon on arrête tout.
bash setup_linux.sh "--only 118:2 --out calib"
.venv/bin/python verify_equivalence.py calib/118_2_8.jsonl calib_reference/118_2_8.jsonl

# 2) La tranche de CETTE machine (i et M sont donnés par le plan ; exemple : tranche 3 sur 9 -> --slice 3/9).
#    nohup : le calcul continue même si tu fermes la connexion.
nohup .venv/bin/python run_jobs.py --slice i/M --workers 26 --out results > run.out 2>&1 &

# 3) Suivre la progression, quand tu veux :
tail -2 results/run_jobs.log          # "... -- 57/381 jobs of this slice done"
```

**À la fin**, `results/run_jobs.log` se termine par `all jobs finished`, et le fichier **`RESULTATS_slice_iofM.tar.gz`** apparaît
dans le dossier. Rapatrie CE fichier (quelques Mo), puis arrête ou supprime la machine : elle coûte tant qu'elle tourne.

**Si une machine s'arrête en cours de route** (interruption spot) : relance la même commande 2) avec le même `--slice`. Les jobs
dont le résultat est déjà dans `results/` sont sautés, et seuls les jobs en cours sont refaits.
