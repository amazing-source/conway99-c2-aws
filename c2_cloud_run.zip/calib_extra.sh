#!/bin/bash
# v2 second calibration: the v2 consumer on a fixed stream of 1,200 pairs of 011 (deep symmetry + twin-canonical rule).
set -u
cd "$(dirname "$0")" || exit 1
mkdir -p calib
rm -f calib/011_trunc_1200.jsonl
env -u FD_SYM3 -u FD_TWINCANON OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMBA_NUM_THREADS=1 FD_LEMMA_U=1 FD_SYM=1 \
  .venv/bin/python scripts/hstage_stream_next.py 11 calib_reference/stream_011_1200.jsonl calib/011_trunc_1200.jsonl > calib/extra.out 2>&1 || exit 1
.venv/bin/python verify_equivalence.py calib/011_trunc_1200.jsonl calib_reference/011_trunc_1200.jsonl || exit 1
.venv/bin/python calib_v3.py check
